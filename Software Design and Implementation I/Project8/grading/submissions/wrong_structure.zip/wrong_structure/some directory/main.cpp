#include <iostream>
#include <string>
#include "Parse.h"
using namespace std;


void print_test1_result() {
    cout << "Hello World\n";
    cout << endl << endl;
    cout << "the answer is 42\n";
}

void print_test2_result() {
    cout << "4 should be 4" << endl;
    cout << "9 should be 9" << endl;
    cout << "5 should be 5" << endl;
    cout << "3 should be 3" << endl;
    cout << "1 should be 1" << endl;
    cout << "0 should be 0" << endl;
    cout << "1 should be 1" << endl;
    cout << "1 should be 1" << endl;
    cout << "0 should be 0" << endl;
    cout << "0 should be 0" << endl;
    cout << "-42 should be -42" << endl;
    cout << "1 should be 1" << endl;
    cout << "0 should be 0" << endl;
}

void run(void) {
    read_next_token();
    string token = next_token();
    if (token == "text")
        print_test1_result();
    else
        print_test2_result();
}

int main(void) {
    set_input("input.blip"); // It's not test_grader.blip
    run();
}
