//
// Created by Arkan Abuyazid on 2018-04-10.
//
#include <iostream>
#include "Text.h"
using namespace std;

void cmdText(void) {
    read_next_token();
    cout << next_token();
}

