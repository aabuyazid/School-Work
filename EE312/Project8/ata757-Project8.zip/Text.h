//
// Created by Arkan Abuyazid on 2018-04-10.
//

#ifndef PROJECT8_TEST_H
#define PROJECT8_TEST_H

#endif //PROJECT8_TEST_H
#include <string.h>
#include "Parse.h"

void cmdText(void);



