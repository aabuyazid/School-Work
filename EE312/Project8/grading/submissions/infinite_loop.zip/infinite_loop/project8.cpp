#include <iostream>
#include "Parse.h"
using namespace std;


void run(void) {
    cout << "I'm running\n";
    while(1);
}

int main(void) {
    set_input("test_grader.blip");
    run();
}
